// WatchTime Popup Script — gr3gg64

const browserAPI = typeof browser !== "undefined" ? browser : chrome;

// ─── Utilities ────────────────────────────────────────────────────────────────

function fmt(seconds) {
  if (seconds < 60) return `${seconds}s`;
  if (seconds < 3600) {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return s > 0 ? `${m}m ${s}s` : `${m}m`;
  }
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  return m > 0 ? `${h}h ${m}m` : `${h}h`;
}

function fmtShort(seconds) {
  if (seconds < 60) return `${seconds}s`;
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m`;
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  return m > 0 ? `${h}h${m}m` : `${h}h`;
}

function dateKey(date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

function faviconUrl(hostname) {
  return `https://www.google.com/s2/favicons?domain=${hostname}&sz=32`;
}

function getWeekDays() {
  const today = new Date();
  const dow = today.getDay(); // 0=Sun
  const days = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(today.getDate() - i);
    days.push(d);
  }
  return days;
}

function getMonthDays(year, month) {
  const days = [];
  const firstDay = new Date(year, month, 1);
  const lastDay = new Date(year, month + 1, 0);
  for (let d = 1; d <= lastDay.getDate(); d++) {
    days.push(new Date(year, month, d));
  }
  return { days, firstDow: firstDay.getDay(), total: lastDay.getDate() };
}

function aggregateSites(data, keys) {
  const totals = {};
  for (const key of keys) {
    const day = data[key] || {};
    for (const [host, secs] of Object.entries(day)) {
      totals[host] = (totals[host] || 0) + secs;
    }
  }
  return Object.entries(totals)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 20);
}

function totalSeconds(data, keys) {
  let t = 0;
  for (const key of keys) {
    const day = data[key] || {};
    for (const secs of Object.values(day)) t += secs;
  }
  return t;
}

// ─── Render helpers ───────────────────────────────────────────────────────────

function renderSiteList(container, sites, maxSecs) {
  container.innerHTML = "";
  if (!sites.length) {
    container.innerHTML = `<div class="empty"><div class="empty-icon">🌐</div>No browsing data yet.<br>Start browsing and come back!</div>`;
    return;
  }
  sites.forEach(([host, secs], idx) => {
    const pct = maxSecs > 0 ? Math.round((secs / maxSecs) * 100) : 0;
    const row = document.createElement("div");
    row.className = "site-row";
    row.innerHTML = `
      <span class="site-rank">${idx + 1}</span>
      <img class="site-favicon" src="${faviconUrl(host)}" onerror="this.style.display='none'" />
      <div class="site-info">
        <div class="site-name">${host}</div>
        <div class="site-bar-wrap"><div class="site-bar" style="width:${pct}%"></div></div>
      </div>
      <div class="site-time">${fmt(secs)}</div>
    `;
    container.appendChild(row);
  });
}

function renderStatCards(container, cards) {
  container.innerHTML = cards.map(({ val, label, cls }) =>
    `<div class="stat-card"><div class="stat-val ${cls || ""}">${val}</div><div class="stat-label">${label}</div></div>`
  ).join("");
}

// ─── TODAY ────────────────────────────────────────────────────────────────────

function renderToday(data) {
  const key = dateKey(new Date());
  const dayData = data[key] || {};
  const sites = Object.entries(dayData).sort((a, b) => b[1] - a[1]).slice(0, 20);
  const totalSecs = sites.reduce((a, [, s]) => a + s, 0);
  const topSite = sites[0] ? sites[0][0] : "—";
  const activeSites = sites.length;
  const avgPerSite = activeSites > 0 ? Math.round(totalSecs / activeSites) : 0;

  renderStatCards(document.getElementById("today-stats"), [
    { val: fmt(totalSecs), label: "Total Today", cls: "green" },
    { val: activeSites, label: "Sites", cls: "pink" },
    { val: fmtShort(avgPerSite), label: "Avg/Site", cls: "cyan" },
  ]);

  const maxSecs = sites[0] ? sites[0][1] : 1;
  renderSiteList(document.getElementById("today-list"), sites, maxSecs);

  document.getElementById("loading-today").style.display = "none";
  document.getElementById("today-content").style.display = "block";
}

// ─── WEEKLY ───────────────────────────────────────────────────────────────────

function renderWeekly(data) {
  const days = getWeekDays();
  const dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  const todayKey2 = dateKey(new Date());

  // Chart
  const weekTotals = days.map(d => totalSeconds(data, [dateKey(d)]));
  const maxDay = Math.max(...weekTotals, 1);
  const chartEl = document.getElementById("week-chart");
  chartEl.innerHTML = "";
  days.forEach((d, i) => {
    const pct = weekTotals[i] / maxDay;
    const barH = Math.max(pct * 56, weekTotals[i] > 0 ? 3 : 0);
    const isToday = dateKey(d) === todayKey2;
    const col = document.createElement("div");
    col.className = "week-col";
    col.innerHTML = `
      <div class="week-bar-wrap" title="${fmt(weekTotals[i])}">
        <div class="week-bar${isToday ? " today" : ""}" style="height:${barH}px;width:100%"></div>
      </div>
      <div class="week-label${isToday ? " today" : ""}">${dayNames[d.getDay()]}</div>
    `;
    chartEl.appendChild(col);
  });

  // Summary
  const weekTotal = weekTotals.reduce((a, b) => a + b, 0);
  const activeDays = weekTotals.filter(t => t > 0).length;
  const avgDay = activeDays > 0 ? Math.round(weekTotal / activeDays) : 0;

  document.getElementById("week-summary").innerHTML = `
    <div class="stat-card"><div class="stat-val green">${fmt(weekTotal)}</div><div class="stat-label">Week Total</div></div>
    <div class="stat-card"><div class="stat-val cyan">${fmt(avgDay)}</div><div class="stat-label">Avg Per Day</div></div>
  `;

  // Range label
  const start = days[0], end = days[6];
  document.getElementById("week-range-label").textContent =
    `${start.toLocaleDateString("en", { month: "short", day: "numeric" })} – ${end.toLocaleDateString("en", { month: "short", day: "numeric", year: "numeric" })}`;

  // Site list
  const keys = days.map(d => dateKey(d));
  const sites = aggregateSites(data, keys);
  const maxSecs = sites[0] ? sites[0][1] : 1;
  renderSiteList(document.getElementById("weekly-list"), sites, maxSecs);

  document.getElementById("loading-weekly").style.display = "none";
  document.getElementById("weekly-content").style.display = "block";
}

// ─── MONTHLY ──────────────────────────────────────────────────────────────────

let selectedMonth = null;

function renderMonthly(data) {
  const now = new Date();
  const today = dateKey(now);

  // Find available months from data
  const allKeys = Object.keys(data).filter(k => /^\d{4}-\d{2}-\d{2}$/.test(k)).sort();
  const months = new Set();
  allKeys.forEach(k => months.add(k.slice(0, 7)));
  const currentMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
  months.add(currentMonth);
  const monthList = [...months].sort().reverse().slice(0, 6);

  if (!selectedMonth || !monthList.includes(selectedMonth)) {
    selectedMonth = currentMonth;
  }

  // Month selector buttons
  const selEl = document.getElementById("month-selector");
  selEl.innerHTML = "";
  monthList.forEach(m => {
    const [y, mo] = m.split("-");
    const label = new Date(+y, +mo - 1, 1).toLocaleDateString("en", { month: "short", year: "2-digit" });
    const btn = document.createElement("div");
    btn.className = "period-btn" + (m === selectedMonth ? " active" : "");
    btn.textContent = label;
    btn.onclick = () => { selectedMonth = m; renderMonthly(data); };
    selEl.appendChild(btn);
  });

  const [selYear, selMo] = selectedMonth.split("-").map(Number);
  const { days, firstDow } = getMonthDays(selYear, selMo - 1);

  // Heat levels
  const daySecs = {};
  days.forEach(d => {
    const k = dateKey(d);
    daySecs[k] = totalSeconds(data, [k]);
  });
  const maxSecs = Math.max(...Object.values(daySecs), 1);

  // Calendar grid
  const grid = document.getElementById("month-grid");
  grid.innerHTML = "";
  const dayLabels = ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"];
  dayLabels.forEach(l => {
    const el = document.createElement("div");
    el.className = "month-day-label";
    el.textContent = l;
    grid.appendChild(el);
  });

  // Empty cells before first day
  for (let i = 0; i < firstDow; i++) {
    const el = document.createElement("div");
    el.className = "month-day empty";
    grid.appendChild(el);
  }

  days.forEach(d => {
    const k = dateKey(d);
    const secs = daySecs[k] || 0;
    const level = secs === 0 ? 0 : Math.ceil((secs / maxSecs) * 5);
    const el = document.createElement("div");
    el.className = "month-day" + (k === today ? " today" : "");
    if (level > 0) el.setAttribute("data-level", level);
    el.textContent = d.getDate();
    el.innerHTML += `<div class="month-tooltip">${d.toLocaleDateString("en", { month: "short", day: "numeric" })}<br>${fmt(secs)}</div>`;
    grid.appendChild(el);
  });

  // Month label
  const monthName = new Date(selYear, selMo - 1, 1).toLocaleDateString("en", { month: "long", year: "numeric" });
  document.getElementById("month-label").textContent = `${monthName} Heatmap`;

  // Month total and avg
  const monthKeys = days.map(d => dateKey(d));
  const sites = aggregateSites(data, monthKeys);
  const maxSite = sites[0] ? sites[0][1] : 1;
  renderSiteList(document.getElementById("monthly-list"), sites, maxSite);

  document.getElementById("loading-monthly").style.display = "none";
  document.getElementById("monthly-content").style.display = "block";
}

// ─── Init ─────────────────────────────────────────────────────────────────────

let allData = {};

function init() {
  browserAPI.runtime.sendMessage({ type: "GET_DATA" }, (data) => {
    allData = data || {};
    renderToday(allData);

    const now = new Date();
    document.getElementById("last-updated").textContent =
      now.toLocaleTimeString("en", { hour: "2-digit", minute: "2-digit" });
  });
}

// Tab switching
document.querySelectorAll(".tab").forEach(tab => {
  tab.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
    document.querySelectorAll(".panel").forEach(p => p.classList.remove("active"));
    tab.classList.add("active");
    const name = tab.dataset.tab;
    document.getElementById(`panel-${name}`).classList.add("active");

    if (name === "weekly") {
      document.getElementById("loading-weekly").style.display = "flex";
      document.getElementById("weekly-content").style.display = "none";
      setTimeout(() => renderWeekly(allData), 50);
    }
    if (name === "monthly") {
      document.getElementById("loading-monthly").style.display = "flex";
      document.getElementById("monthly-content").style.display = "none";
      setTimeout(() => renderMonthly(allData), 50);
    }
  });
});

// Clear data
document.getElementById("clearBtn").addEventListener("click", () => {
  if (confirm("Clear ALL WatchTime data? This cannot be undone.")) {
    browserAPI.runtime.sendMessage({ type: "CLEAR_DATA" }, () => {
      allData = {};
      renderToday({});
    });
  }
});

init();
