// WatchTime Background Script — gr3gg64
// Handles time tracking, storage, and tab/window events

const TICK_INTERVAL = 5; // seconds
let activeTabId = null;
let activeWindowId = null;
let activeHostname = null;
let tickStart = null;
let isIdle = false;

// ─── Helpers ──────────────────────────────────────────────────────────────────

function getHostname(url) {
  try {
    if (!url || url.startsWith("chrome://") || url.startsWith("moz-extension://") || url.startsWith("about:")) return null;
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return null;
  }
}

function todayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

// ─── Storage ──────────────────────────────────────────────────────────────────

async function addTime(hostname, seconds) {
  if (!hostname || seconds <= 0) return;
  const key = todayKey();
  const storageArea = typeof browser !== "undefined" ? browser.storage.local : chrome.storage.local;

  return new Promise((resolve) => {
    storageArea.get([key], (result) => {
      const dayData = result[key] || {};
      dayData[hostname] = (dayData[hostname] || 0) + seconds;
      storageArea.set({ [key]: dayData }, resolve);
    });
  });
}

async function getAllData() {
  const storageArea = typeof browser !== "undefined" ? browser.storage.local : chrome.storage.local;
  return new Promise((resolve) => {
    storageArea.get(null, (result) => resolve(result || {}));
  });
}

// ─── Tick Logic ───────────────────────────────────────────────────────────────

function startTick(hostname) {
  activeHostname = hostname;
  tickStart = Date.now();
}

async function flushTick() {
  if (activeHostname && tickStart && !isIdle) {
    const elapsed = Math.round((Date.now() - tickStart) / 1000);
    if (elapsed > 0) await addTime(activeHostname, elapsed);
  }
  tickStart = activeHostname ? Date.now() : null;
}

// ─── Tab Events ───────────────────────────────────────────────────────────────

async function onTabChange(tabId, windowId) {
  await flushTick();

  const browserAPI = typeof browser !== "undefined" ? browser : chrome;
  if (!tabId) { activeHostname = null; return; }

  try {
    const tab = await new Promise((res, rej) => {
      browserAPI.tabs.get(tabId, (t) => {
        if (browserAPI.runtime.lastError) rej(browserAPI.runtime.lastError);
        else res(t);
      });
    });
    const hostname = getHostname(tab.url);
    activeTabId = tabId;
    activeWindowId = windowId;
    if (hostname) startTick(hostname);
    else { activeHostname = null; tickStart = null; }
  } catch {
    activeHostname = null;
    tickStart = null;
  }
}

// Periodic flush alarm
const browserAPI = typeof browser !== "undefined" ? browser : chrome;

browserAPI.alarms.create("tick", { periodInMinutes: TICK_INTERVAL / 60 });
browserAPI.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === "tick") await flushTick();
});

// Tab activated
browserAPI.tabs.onActivated.addListener(({ tabId, windowId }) => {
  onTabChange(tabId, windowId);
});

// Tab updated (navigation)
browserAPI.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (tabId === activeTabId && changeInfo.url) {
    flushTick().then(() => {
      const hostname = getHostname(changeInfo.url);
      if (hostname) startTick(hostname);
      else { activeHostname = null; tickStart = null; }
    });
  }
});

// Window focus
browserAPI.windows.onFocusChanged.addListener(async (windowId) => {
  if (windowId === browserAPI.windows.WINDOW_ID_NONE) {
    await flushTick();
    activeHostname = null;
    tickStart = null;
  } else {
    browserAPI.tabs.query({ active: true, windowId }, (tabs) => {
      if (tabs && tabs[0]) onTabChange(tabs[0].id, windowId);
    });
  }
});

// Idle detection
if (browserAPI.idle) {
  browserAPI.idle.setDetectionInterval(60);
  browserAPI.idle.onStateChanged.addListener(async (state) => {
    if (state === "idle" || state === "locked") {
      await flushTick();
      isIdle = true;
      activeHostname = null;
      tickStart = null;
    } else if (state === "active") {
      isIdle = false;
      browserAPI.tabs.query({ active: true, lastFocusedWindow: true }, (tabs) => {
        if (tabs && tabs[0]) onTabChange(tabs[0].id, tabs[0].windowId);
      });
    }
  });
}

// Init on startup
browserAPI.tabs.query({ active: true, lastFocusedWindow: true }, (tabs) => {
  if (tabs && tabs[0]) onTabChange(tabs[0].id, tabs[0].windowId);
});

// Message handler for popup
browserAPI.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "GET_DATA") {
    // Flush current tick first
    flushTick().then(() => {
      getAllData().then(sendResponse);
    });
    return true;
  }
  if (msg.type === "CLEAR_DATA") {
    const storageArea = typeof browser !== "undefined" ? browser.storage.local : chrome.storage.local;
    storageArea.clear(() => sendResponse({ ok: true }));
    return true;
  }
});
