// WatchTime Content Script — gr3gg64
// Notifies background on visibility changes

(function () {
  const browserAPI = typeof browser !== "undefined" ? browser : chrome;

  function notifyVisibility(visible) {
    try {
      browserAPI.runtime.sendMessage({ type: visible ? "PAGE_VISIBLE" : "PAGE_HIDDEN" });
    } catch (_) {}
  }

  document.addEventListener("visibilitychange", () => {
    notifyVisibility(!document.hidden);
  });
})();
