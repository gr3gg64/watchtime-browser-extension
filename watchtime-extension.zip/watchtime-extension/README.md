# WatchTime — Browser Extension
**by gr3gg64**

Track how long you spend on every website. Get weekly reviews, daily averages, and monthly heatmaps.

---

## Features
- ⏱ **Real-time tracking** — measures active tab time, pauses when idle
- 📊 **Today view** — total time, site count, avg per site
- 📅 **Weekly review** — bar chart of the last 7 days + avg per day
- 🗓 **Monthly heatmap** — activity calendar + top sites per month
- 🔒 **100% local** — all data stored in your browser, never sent anywhere

---

## Installation

### Chrome / Chromium
1. Go to `chrome://extensions/`
2. Enable **Developer Mode** (top right toggle)
3. Click **Load unpacked**
4. Select the `watchtime-extension` folder
5. Done! The ⏱ icon will appear in your toolbar.

### Firefox
1. Rename `manifest_firefox.json` → `manifest.json` (replace the existing one)
2. Go to `about:debugging#/runtime/this-firefox`
3. Click **Load Temporary Add-on**
4. Select `manifest.json` inside the `watchtime-extension` folder
5. Done!

> **Firefox permanent install**: Sign the extension via [addons.mozilla.org](https://addons.mozilla.org/en-US/developers/) or use Firefox Developer Edition which allows unsigned extensions.

---

## Usage
- Click the ⏱ toolbar icon to open the popup
- Switch between **Today / Weekly / Monthly** tabs
- The 🗑 button clears all stored data

---

## File Structure
```
watchtime-extension/
├── manifest.json          ← Chrome/Chromium (MV3)
├── manifest_firefox.json  ← Firefox (MV2)
├── background.js          ← Tracking logic
├── content.js             ← Page visibility handler
├── icons/
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
└── popup/
    ├── popup.html         ← UI
    └── popup.js           ← Data rendering
```

---

*WatchTime v1.0 — gr3gg64*
